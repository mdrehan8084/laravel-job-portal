<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\RecruiterJobController;
use Illuminate\Support\Facades\Route;

// Public pages
Route::get('/', [JobController::class, 'home'])->name('home');
Route::get('/jobs', [JobController::class, 'index'])->name('jobs.index');
Route::get('/jobs/{jobListing}', [JobController::class, 'show'])->name('jobs.show');

// Guests only
Route::middleware('guest')->group(function () {
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// Logged-in users only
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/dashboard', function () {
        return redirect()->route(auth()->user()->role . '.dashboard');
    })->name('dashboard');

    Route::get('/admin', fn () => view('dashboards.admin'))
        ->middleware('role:admin')->name('admin.dashboard');

    Route::get('/candidate', fn () => view('dashboards.candidate'))
        ->middleware('role:candidate')->name('candidate.dashboard');

    // Recruiter area
    Route::middleware('role:recruiter')
        ->prefix('recruiter')
        ->name('recruiter.')
        ->group(function () {
            Route::get('/', fn () => redirect()->route('recruiter.jobs.index'))->name('dashboard');

            Route::patch('jobs/{jobListing}/toggle', [RecruiterJobController::class, 'toggle'])
                ->name('jobs.toggle');

            Route::resource('jobs', RecruiterJobController::class)
                ->parameters(['jobs' => 'jobListing'])
                ->except('show');
        });
});