<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Admin',
            'email' => 'admin@demo.com',
            'password' => 'password',
            'role' => 'admin',
        ]);

        $recruiter = User::create([
            'name' => 'Tech Recruiter',
            'email' => 'recruiter@demo.com',
            'password' => 'password',
            'role' => 'recruiter',
        ]);

        User::create([
            'name' => 'Demo Candidate',
            'email' => 'candidate@demo.com',
            'password' => 'password',
            'role' => 'candidate',
        ]);

       $jobs = [
    ['Laravel Developer', 'TechNova Solutions', 'Delhi', 'full-time', 25000, 40000,
        'Work on Laravel and MySQL applications. You should understand REST APIs, authentication and Eloquent well.'],
    ['React Frontend Developer', 'PixelCraft Studio', 'Noida', 'full-time', 30000, 50000,
        'Build responsive user interfaces with React, hooks and Bootstrap. Experience with API integration is a plus.'],
    ['WordPress Developer', 'WebWorks Agency', 'Gurugram', 'full-time', 20000, 32000,
        'Create custom themes and plugins. Good knowledge of HTML, CSS, PHP and WordPress is required.'],
    ['PHP Developer Intern', 'CodeBridge Labs', 'Delhi', 'internship', 8000, 12000,
        'For freshers. Learn core PHP and MySQL while working alongside senior developers.'],
    ['Full Stack Developer', 'RemoteFirst Tech', 'Remote', 'remote', 35000, 60000,
        'Work on both frontend (React) and backend (Laravel). Fully remote with flexible working hours.'],
    ['Bootstrap UI Developer', 'Designify', 'Mumbai', 'part-time', 15000, 22000,
        'Build landing pages and dashboards using Bootstrap 5, jQuery and JavaScript.'],
];
        foreach ($jobs as [$title, $company, $location, $type, $min, $max, $description]) {
            $recruiter->jobListings()->create([
                'title' => $title,
                'company' => $company,
                'location' => $location,
                'type' => $type,
                'salary_min' => $min,
                'salary_max' => $max,
                'description' => $description,
            ]);
        }
    }
}