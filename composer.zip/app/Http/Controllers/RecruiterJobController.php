<?php

namespace App\Http\Controllers;

use App\Http\Requests\JobListingRequest;
use App\Models\JobListing;
use Illuminate\Support\Facades\Gate;

class RecruiterJobController extends Controller
{
    // List only the logged-in recruiter's jobs
    public function index()
    {
        $jobs = auth()->user()->jobListings()->latest()->paginate(8);

        return view('recruiter.jobs.index', compact('jobs'));
    }

    public function create()
    {
        return view('recruiter.jobs.create');
    }

    public function store(JobListingRequest $request)
    {
        $data = $request->validated();
        $data['is_active'] = $request->boolean('is_active');

        $request->user()->jobListings()->create($data);

        return redirect()
            ->route('recruiter.jobs.index')
            ->with('success', 'Job posted successfully.');
    }

    public function edit(JobListing $jobListing)
    {
        Gate::authorize('update', $jobListing);

        return view('recruiter.jobs.edit', ['job' => $jobListing]);
    }

    public function update(JobListingRequest $request, JobListing $jobListing)
    {
        Gate::authorize('update', $jobListing);

        $data = $request->validated();
        $data['is_active'] = $request->boolean('is_active');

        $jobListing->update($data);

        return redirect()
            ->route('recruiter.jobs.index')
            ->with('success', 'Job updated successfully.');
    }

    public function destroy(JobListing $jobListing)
    {
        Gate::authorize('delete', $jobListing);

        $jobListing->delete();

        return redirect()
            ->route('recruiter.jobs.index')
            ->with('success', 'Job deleted.');
    }

    // Switch a job between active and inactive
    public function toggle(JobListing $jobListing)
    {
        Gate::authorize('update', $jobListing);

        $jobListing->update(['is_active' => ! $jobListing->is_active]);

        return back()->with('success', 'Job status updated.');
    }
}