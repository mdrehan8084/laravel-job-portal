<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobListing extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'company',
        'location',
        'type',
        'salary_min',
        'salary_max',
        'description',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
        ];
    }

    // Ek job ek recruiter (user) ki hoti hai
    public function recruiter()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // Sirf active jobs: JobListing::active()->get()
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}