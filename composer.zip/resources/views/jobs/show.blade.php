@extends('layouts.app')

@section('title', $job->title)

@section('content')
<a href="{{ route('jobs.index') }}" class="text-decoration-none">← All jobs</a>

<div class="row mt-3">
    <div class="col-lg-8">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h2 class="mb-1">{{ $job->title }}</h2>
                        <h5 class="text-muted">{{ $job->company }}</h5>
                    </div>
                    <span class="badge bg-primary text-capitalize fs-6">{{ $job->type }}</span>
                </div>

                <hr>

                <div class="row mb-3">
                    <div class="col-sm-4"><strong>📍 Location</strong><br>{{ $job->location }}</div>
                    <div class="col-sm-4">
                        <strong>💰 Salary</strong><br>
                        @if($job->salary_min && $job->salary_max)
                            ₹{{ number_format($job->salary_min) }} - ₹{{ number_format($job->salary_max) }} / month
                        @else
                            Not specified
                        @endif
                    </div>
                    <div class="col-sm-4"><strong>🕒 Posted</strong><br>{{ $job->created_at->diffForHumans() }}</div>
                </div>

                <h5>Job description</h5>
                <p style="white-space: pre-line;">{{ $job->description }}</p>

                <p class="text-muted small mb-0">
                    Posted by: {{ $job->recruiter->name }}
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body text-center">
                @guest
                    <p class="text-muted">Please log in to apply for this job.</p>
                    <a href="{{ route('login') }}" class="btn btn-primary w-100">Log in to Apply</a>
                @endguest

                @auth
                    @if(auth()->user()->isCandidate())
                        <button class="btn btn-success w-100" disabled>Apply Now</button>
                        <small class="text-muted d-block mt-2">Applications will open soon.</small>
                    @else
                        <p class="text-muted mb-0">Only candidates can apply for jobs.</p>
                    @endif
                @endauth
            </div>
        </div>

        @if($related->count())
            <h6 class="mb-3">Similar jobs</h6>
            @foreach($related as $item)
                <a href="{{ route('jobs.show', $item) }}" class="card shadow-sm border-0 mb-2 text-decoration-none">
                    <div class="card-body py-2">
                        <strong>{{ $item->title }}</strong><br>
                        <small class="text-muted">{{ $item->company }} · {{ $item->location }}</small>
                    </div>
                </a>
            @endforeach
        @endif
    </div>
</div>
@endsection