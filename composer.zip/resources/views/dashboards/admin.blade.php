@extends('layouts.app')

@section('title', 'Admin Dashboard')

@section('content')
<h3>Admin Dashboard</h3>
<p class="text-muted">User and job statistics and charts will appear here..</p>
@endsection