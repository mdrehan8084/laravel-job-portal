@extends('layouts.app')

@section('title', 'Candidate Dashboard')

@section('content')
<h3>Candidate Dashboard</h3>
<p class="text-muted">Your applications and their status will appear here.</p>
@endsection