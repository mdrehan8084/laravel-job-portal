@extends('layouts.app')

@section('title', 'My Jobs')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h3 class="mb-0">My Jobs</h3>
        <small class="text-muted">{{ $jobs->total() }} jobs posted</small>
    </div>
    <a href="{{ route('recruiter.jobs.create') }}" class="btn btn-primary">+ Post a Job</a>
</div>

<div class="card shadow-sm border-0">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Job</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Salary (₹/month)</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($jobs as $job)
                    <tr>
                        <td>
                            <strong>{{ $job->title }}</strong><br>
                            <small class="text-muted">{{ $job->company }}</small>
                        </td>
                        <td>{{ $job->location }}</td>
                        <td class="text-capitalize">{{ $job->type }}</td>
                        <td>{{ number_format($job->salary_min) }} - {{ number_format($job->salary_max) }}</td>
                        <td>
                            @if($job->is_active)
                                <span class="badge bg-success">Active</span>
                            @else
                                <span class="badge bg-secondary">Inactive</span>
                            @endif
                        </td>
                        <td class="text-end">
                            <a href="{{ route('recruiter.jobs.edit', $job) }}"
                               class="btn btn-sm btn-outline-primary">Edit</a>

                            <form action="{{ route('recruiter.jobs.toggle', $job) }}" method="POST" class="d-inline">
                                @csrf
                                @method('PATCH')
                                <button class="btn btn-sm btn-outline-secondary">
                                    {{ $job->is_active ? 'Deactivate' : 'Activate' }}
                                </button>
                            </form>

                            <form action="{{ route('recruiter.jobs.destroy', $job) }}" method="POST" class="d-inline"
                                  onsubmit="return confirm('Delete this job? This cannot be undone.');">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            You have not posted any jobs yet.
                            <a href="{{ route('recruiter.jobs.create') }}">Post your first job</a>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-4">
    {{ $jobs->links() }}
</div>
@endsection